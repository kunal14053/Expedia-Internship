
 

// chrome.browserAction.onClicked.addListener(function(){

//  chrome.tabs.create({url:/*'https://google.com'*/ chrome.extension.getURL('popup.html')});
   
//    chrome.tabs.executeScript(null,{
//       code: "console.log('Hello It Is Working');"
//         code:"console.log('Hello!');x=document.getElementById('departure-date-0');alert(x.textContent);"
//       code:"console.log('Hello!');x=document.getElementsByClassName('segment-info info cf');console.log(x[0].innerText);"
      
//     });
//     var information=1234;
//     chrome.tabs.executeScript(null,{
//       code: 'var information = "'+information+'";'},function(){
//           chrome.tabs.executeScript(null,{file:'script.js'})
//       });
    
//     chrome.tabs.executeScript(null,{file:'script.js'})
    
    

// });

//     "browser_action" 
//     "default_icon": "icon.png",
//     "default_popup": "popup.html",

var x='',y='';

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('create').addEventListener('click', function() {

    
    var table = document.getElementById("myTableData");
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);

    chrome.tabs.executeScript(null,{
         code:"document.getElementById('departure-date-0').textContent;"      
       },receiveText1);    
    
    function receiveText1(resultsArray){
      x=resultsArray[0];
    };

    

chrome.tabs.executeScript(null,{
         code:"document.getElementsByClassName('name')[0].innerText;"      
       },receiveText2);


    function receiveText2(resultsArray){
      y=resultsArray[0];
    };

    row.insertCell(0).innerHTML='';
    row.insertCell(1).innerHTML= x;
    row.insertCell(2).innerHTML= y;
    row.insertCell(3).innerHTML='';
});

});


// document.getElementById("add").addEventListener('addRow', function() {
//     var myName = document.getElementById("name");
//     var age = document.getElementById("age");
//     var table = document.getElementById("myTableData");

//     var rowCount = table.rows.length;
//     var row = table.insertRow(rowCount);

//     row.insertCell(0).innerHTML= '<input type="button" value = "Delete" onClick="Javacsript:deleteRow(this)">';
//     row.insertCell(1).innerHTML= myName.value;
//     row.insertCell(2).innerHTML= age.value;
// });


// function addRow() {
         
//     var myName = document.getElementById("name");
//     var age = document.getElementById("age");
//     var table = document.getElementById("myTableData");

//     var rowCount = table.rows.length;
//     var row = table.insertRow(rowCount);

//     row.insertCell(0).innerHTML= '<input type="button" value = "Delete" onClick="Javacsript:deleteRow(this)">';
//     row.insertCell(1).innerHTML= myName.value;
//     row.insertCell(2).innerHTML= age.value;

// },



